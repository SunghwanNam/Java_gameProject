
public class MainClass {
	public static void main(String[] args) {
		GameManager gameManager = new GameManager();
		gameManager.playGame();
	}
}
