import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class GameManager {
	public void playGame() {
		Unit[] team0 = { new Fire(), new Plant(), new Thunder(), new Water() };
		Unit[] team1 = { new RocketMajayong(), new RocketFamCobra(), new RocketCat(), new Unit() };

		Scanner scanner = new Scanner(System.in);
		Random random = new Random();
		Random random2 = new Random();
		for (int i = 0; i < 999999; i++) {
			System.out.println("턴 진행을 하려면 enter를 누르세요.");
			scanner.nextLine();
			int team0Index = -1;
			int team1Index = -1;
			for (int j = 0; j < 999; j++) {
				team0Index = random.nextInt(team0.length);
				if (team0[team0Index].hp < 1) {
					continue;
				} else {
					break;
				}
			}
			for (int j = 0; j < 999; j++) {
				team1Index = random2.nextInt(team1.length);
				if (team1[team1Index].hp < 1) {
					continue;
				} else {
					break;
				}
			}
//			int team0Index = random.nextInt(team0.length);
//			int team1Index = random.nextInt(team1.length);
			if (team0[team0Index].hp > 0 || team1[team1Index].hp > 0) {
				team0[team0Index].underAttack(team1[team1Index].getPower());
				team1[team1Index].underAttack(team0[team0Index].getPower());
			} else {
				continue;
			}

//			boolean team0IsAlive = false;
//			for (int j = 0; j < team0.length; j++) {
//				team0IsAlive = team0IsAlive || team0[j].isLive();
//			}

			if (team0[0].isLive() == false && team0[1].isLive() == false && team0[2].isLive() == false
					&& team0[3].isLive() == false) {
				System.out.println("팀 트레이너스가 전멸 하였습니다.");
				System.out.println("로켓단 승리. 게임종료");

				break;
			} else if (team1[0].isLive() == false && team1[1].isLive() == false && team1[2].isLive() == false
					&& team1[3].isLive() == false) {
				System.out.println("로켓단이 전멸 하였습니다.");
				System.out.println("팀 트레이너스 승리. 게임종료");
				break;
			}

		}
	}
}
